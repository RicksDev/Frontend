function rollDice() {
    return Math.floor(Math.random() * 6) + 1;
}

function updateDiceImage(diceNumber) {
    var diceImage = document.querySelector(".dice");
    diceImage.src = "dice-" + diceNumber + ".png";
}

var scores = [0, 0];
var currentPlayer = 0;

const updateCurrent = (current) => {
    var currentElement = document.getElementById("current--" + currentPlayer);
    let newTotalCurrent = parseInt(currentElement.textContent) + current;
    currentElement.textContent = newTotalCurrent;
}

const switchPlayer = () => {
    document.getElementById("current--" + currentPlayer).textContent = "0";
    currentPlayer = currentPlayer === 0 ? 1 : 0;

    document.querySelectorAll('.player').forEach((player) => {
        player.classList.toggle('player--active');
    });
}

document.querySelector(".btn--roll").addEventListener("click", () => {
    var randomNumber = rollDice();
    updateDiceImage(randomNumber);
    if (randomNumber === 1) {
        switchPlayer();
    } else {
        updateCurrent(randomNumber);
    }
});

const hold = document.querySelector(".btn--hold");
hold.addEventListener("click", () => {
    var scoreElement = document.querySelector("#score--" + currentPlayer);
    let newTotalScore = parseInt(scoreElement.textContent) + parseInt(document.getElementById("current--" + currentPlayer).textContent);
    scoreElement.textContent = newTotalScore;
    switchPlayer();
});